
<?php // INCLUDE BAZA

include "db.php";

?>

<!-- HTML BEGINS -->

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="style.css">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
 
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="row">
    <div class="col-md-1" style="background-color:black;">.col</div>
    <div class="col-md-10" style="background-color:dimGray;">
    
    
    <ul>
      <li><a class="active" href="#home">Home</a></li>
      <li><a href="#news">News</a></li>
      <li><a href="police.php">Police</a></li>
      <li><a href="klijenti.php">Klijenti</a></li>
    </ul>
    
    
    
    
    
    

<!-- Modal -->
<div class="modal fade" id="dodajpolicu" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Dodaj Policu</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         
            
        <form action="klijenti.php" method="post">
            <div class="form-group">
            <label>Ime:</label>
                <input type="text" name="firstname" class="form-control">
            </div>
            <div class="form-group">
                <label>Prezime:</label>
                <input type="text" name="lastname" class="form-control">
            </div>
            <div class="form-group">
                <label>Grad:</label>
                <input type="text" name="city" class="form-control">
            </div>
            <div class="form-group">
                 <label>OIB:</label>
                <input type="text" name="oib" class="form-control">
            </div>  
                <input type="submit" name = "create" value="Create" class="btn btn-primary">
        </form>
            
            
            
            <?php
    
                if(isset($_POST['create'])){
                    
                    $ime = $_POST['firstname'];
                    $prezime = $_POST['lastname'];
                    $grad = $_POST['city'];
                    $oib = $_POST['oib'];
                    
                    $query_create = "INSERT INTO klijent (ime, prezime, grad, oib) VALUES ('$ime','$prezime','$grad',$oib) ";
                    
                    $result_create = mysqli_query($connection,$query_create);
                    if(!$result_create){
                        die("ERROR");
                    }
                    header("Location: klijenti.php");
                }
    
    
            ?>
            
            
         
         
      </div>
      
    </div>
  </div>
</div>
    
    
<!--#####################################################################################################################-->
    
    

    
    
    
 <!--#####################################################################################################################-->
    
    
    
    
    <br><br><br>
<div class="container" style="text-align:center;" style="margin-top:30px;">
    
    <h2 style="color:white;">PRIKAZ SVIH KLJENATA</h2>
    
        
        
    
</div>
                         
                         
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#dodajpolicu">
                Dodaj novog
                </button>
                <br><br>

<table class="table table-dark table-striped">
    
     
           
           <tr>
  <th>Id</th>
  <th>Ime</th>
  <th>Prezime</th>
  <th>Grad</th>
  <th>OIB</th>
  <th>Mogucnosti</th>
  </tr>
            
          
            <?php
    
    $query = "SELECT * FROM klijent";
    $result = mysqli_query($connection,$query);
    
    while($row=mysqli_fetch_assoc($result)){
        
        $id = $row['id'];
        $name = $row['ime'];
        $surname = $row['prezime'];
        $city = $row['grad'];
        $oib = $row['oib'];
        
        echo "<tr>";
        echo "<td>$id</td>";
        echo "<td>$name</td>";
        echo "<td>$surname</td>";
        echo "<td>$city</td>";
        echo "<td>$oib</td>";
        //echo "<td><a href='klijenti.php?showpoliceid={$id}' class='btn btn-primary'>Police</a></td>";
        ?>
        
        <td><input type="button" name="view" value="view" id="<?php echo $row["id"]; ?>" class="btn btn-primary btn-xs view_data" /></td>
        
        <?php
        echo "</tr>";
        
    }
    

      ?>
            



    


 

</table>
        
    <br><br>
    
        
    </div>
    <div class="col-md-1" style="background-color:black;">.col</div>
</div>



   

</body>
</html>




<div id="dataModal" class="modal fade">  
      <div class="modal-dialog">  
           <div class="modal-content">  
                <div class="modal-header">  
                     <button type="button" class="close" data-dismiss="modal">&times;</button>  
                     <h4 class="modal-title">Prikaz polica</h4>  
                </div>  
                <div class="modal-body" id="employee_detail">  
                </div>  
                <div class="modal-footer">  
                     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
                </div>  
           </div>  
      </div>  
 </div>  
   
   
   <script>  
 $(document).ready(function(){  
      $('.view_data').click(function(){  
           var employee_id = $(this).attr("id");  
           $.ajax({  
                url:"select.php",  
                method:"post",  
                data:{employee_id:employee_id},  
                success:function(data){  
                     $('#employee_detail').html(data);  
                     $('#dataModal').modal("show");  
                }  
           });  
      });  
 });  
 </script>















