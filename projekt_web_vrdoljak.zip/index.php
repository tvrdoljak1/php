<!DOCTYPE html>
<html>
<head>
<style>
    
    html{
        
    }
    
    
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
    width: auto;
    float: right;
}

li {
  float: right;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #111;
}
    
    

    
 table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
th, td {
  padding: 5px;
  text-align: left;    
}
</style>
</head>
<body>



<ul>
  <li><a class="active" href="#home">Home</a></li>
  <li><a href="#news">News</a></li>
  <li><a href="police.php">Police</a></li>
  <li><a href="klijenti.php">Klijenti</a></li>
</ul>

    


    
  
    

</body>
</html>