<?php

$connection = mysqli_connect('localhost','root','','osiguranje');

if(!$connection){
    echo "NOT CONNECTED";
}
?>