-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 03, 2020 at 04:42 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `osiguranje`
--

-- --------------------------------------------------------

--
-- Table structure for table `klijent`
--

CREATE TABLE `klijent` (
  `id` int(11) NOT NULL,
  `ime` varchar(32) NOT NULL,
  `prezime` varchar(32) NOT NULL,
  `grad` varchar(32) NOT NULL,
  `oib` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `klijent`
--

INSERT INTO `klijent` (`id`, `ime`, `prezime`, `grad`, `oib`) VALUES
(2, 'Jure', 'Majić', 'split', '65147254783'),
(3, 'Marko', 'Tokić', 'zagreb', '25462142587'),
(8, 'Ivana', 'Rozic', 'Split', '63214785784'),
(9, 'Magdalena', 'Ivanisevic', 'Zagreb', '25469874512'),
(10, 'Mirko', 'Marević', 'Split', '56478974587'),
(11, 'Ivanka', 'Baraba', 'Split', '02145247854'),
(12, 'Anđela', 'Jurjević', 'Zadar', '45178414784'),
(13, 'Tomislav', 'Vrdoljak', 'Split', '223322344'),
(14, 'Ivanka', 'Jukic', 'Imotski', '3345678'),
(17, 'Nela', 'Galic', 'Split', '2275869'),
(41, 'Bill', 'Gates', 'imocki', '1212'),
(42, 'Anica', 'Dragun', 'Sibenik', '6666'),
(43, 'connor', 'Gates', 'imocki', '6666');

-- --------------------------------------------------------

--
-- Table structure for table `police`
--

CREATE TABLE `police` (
  `id` int(11) NOT NULL,
  `brojPolice` int(11) NOT NULL,
  `datumPocetka` datetime NOT NULL,
  `datumIsteka` datetime NOT NULL,
  `vrijednost` int(11) NOT NULL,
  `klijentId` int(11) NOT NULL,
  `vrsteOsiguranjaId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `police`
--

INSERT INTO `police` (`id`, `brojPolice`, `datumPocetka`, `datumIsteka`, `vrijednost`, `klijentId`, `vrsteOsiguranjaId`) VALUES
(57, 66666, '1970-01-01 00:00:00', '1970-01-01 00:00:00', 333, 2, 3),
(76, 89, '2020-01-31 00:00:00', '2020-03-26 00:00:00', 800, 10, 3),
(85, 1212, '2020-01-14 00:00:00', '2020-01-25 00:00:00', 2333, 13, 1),
(86, 4555, '2020-01-11 00:00:00', '2020-01-31 00:00:00', 2000, 14, 5),
(87, 100, '2020-02-12 00:00:00', '2020-01-31 00:00:00', 2000, 3, 1),
(92, 432, '2020-02-06 00:00:00', '2020-03-11 00:00:00', 2432, 9, 1),
(93, 343, '2020-05-13 00:00:00', '2020-09-16 00:00:00', 122, 2, 1),
(94, 4, '2020-05-13 00:00:00', '2020-08-12 00:00:00', 45, 2, 1),
(95, 121, '2020-05-05 00:00:00', '2020-07-22 00:00:00', 2000, 12, 7),
(96, 34, '2020-09-09 00:00:00', '2020-11-11 00:00:00', 20000, 12, 4);

-- --------------------------------------------------------

--
-- Table structure for table `vrsteosiguranja`
--

CREATE TABLE `vrsteosiguranja` (
  `id` int(11) NOT NULL,
  `naziv` varchar(32) CHARACTER SET latin1 NOT NULL,
  `opis` text CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vrsteosiguranja`
--

INSERT INTO `vrsteosiguranja` (`id`, `naziv`, `opis`) VALUES
(1, 'AUTOMOBILSKA OSIGURANJA', 'Odlu?ite se za automobilsko osiguranje koje vam jam?i najpovoljnije pokri?e kojim ?ete na najbolji mogu?i na?in osigurati sebe, suputnike i vozilo.'),
(2, 'OSIGURANJE OD POSLJEDICA NESRETN', 'Postoje stvari koje ne možete predvidjeti. Zato izaberite odgovaraju?i oblik osiguranja za slu?aj nezgode.'),
(3, 'OSIGURANJE IMOVINE', 'Svjesni vrijednosti vaše imovine, nudimo vam osiguranje vašeg doma s kvalitetnim pokri?ima za gotovo sve vrste rizika koji mu prijete, a protiv kojih se možete u?inkovito osigurati.'),
(4, 'OSIGURANJE PLOVILA I ZRAKOPLOVA', 'Letenje je uvijek nepredvidivo. Izaberite dobro kasko osiguranje vašeg zrakoplova i odgovaraju?e osiguranje od odgovornosti vlasnika ili pilota prema tre?im osobama i putnicima. Na moru su, uz lijepe doživljaje, uvijek mogu?i i nepredvidivi doga?aji ili loše vremenske prilike, razne druge neugodnosti i nezgode. Ništa ne prepuštajte slu?aju i izaberite dobro osiguranje.'),
(5, 'OSIGURANJE USJEVA I NASADA', 'Pobrinite se da tu?a, mraz, poplave, požari, olujni vjetar i druge neugodnosti ne ugroze vaš prihod radi uništenih ili smanjenih prinosa.'),
(6, 'PUTNA OSIGURANJA', 'Na najbolje isplaniranim putovanjima i na kratkim izletima u inozemstvu, može vam se dogoditi nešto nepredvidivo, nesre?a ili bolest.'),
(7, 'TRANSPORTNO OSIGURANJE', 'Uz osiguranje prijevoznih sredstava pobrinite se i za osiguranje tereta tijekom prijevoza, odgovornosti prijevoznika i špeditera, te odgovornosti voditelja vodenih plovila i pilota zrakoplova.'),
(8, 'ŽIVOTNO OSIGURANJE', 'Možete birati izme?u životnog osiguranja koje uklju?uje samo komponentu osiguranja ili bilo kojeg drugog oblika osiguranja s profitabilnom kombinacijom i osiguranja i štednje.'),
(9, 'ZDRAVSTVENA OSIGURANJAA', 'Ugovoriti policu dopunskog i/ili dobrovoljnog zdravstvenog osiguranja zna?i donijeti odluku da ?ete uvijek, baš uvijek, biti dobro. Sigurni u svoje zdravlje i s povjerenjem prepušteni najboljem što vam daje zdravstveni sustav.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `klijent`
--
ALTER TABLE `klijent`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `police`
--
ALTER TABLE `police`
  ADD PRIMARY KEY (`id`),
  ADD KEY `klijentId` (`klijentId`),
  ADD KEY `vrsteOsiguranjaId` (`vrsteOsiguranjaId`);

--
-- Indexes for table `vrsteosiguranja`
--
ALTER TABLE `vrsteosiguranja`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `klijent`
--
ALTER TABLE `klijent`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `police`
--
ALTER TABLE `police`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;

--
-- AUTO_INCREMENT for table `vrsteosiguranja`
--
ALTER TABLE `vrsteosiguranja`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `police`
--
ALTER TABLE `police`
  ADD CONSTRAINT `police_ibfk_1` FOREIGN KEY (`klijentId`) REFERENCES `klijent` (`id`),
  ADD CONSTRAINT `police_ibfk_2` FOREIGN KEY (`vrsteOsiguranjaId`) REFERENCES `vrsteosiguranja` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
