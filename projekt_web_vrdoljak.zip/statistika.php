<?php // INCLUDE BAZA

include "db.php";

?>

<!-- HTML BEGINS -->

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="style.css">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
 
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="row">
    <div class="col-md-1" style="background-color:black;">.col</div>
    <div class="col-md-10" style="background-color:dimGray;">
    
    
    <ul>
      <li><a class="active" href="#home">Home</a></li>
      <li><a href="#news">News</a></li>
      <li><a href="police.php">Police</a></li>
      <li><a href="klijenti.php">Klijenti</a></li>
	  <li><a href="statistika.php">Statistika</a></li>
    </ul>
    
    
    
   
    
    

<!-- Modal -->
<div class="modal fade" id="dodajpolicu" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Dodaj Policu</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         
         
         
         
         
         
         
         
       


<br>


                            
                            
                            
                            <br><br>
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
      </div>
      
    </div>
  </div>
</div>
    
    
<!--#####################################################################################################################-->
    
    

    
    
    
 <!--#####################################################################################################################-->
    
    
    
    
    <br><br><br>
<div class="container" style="text-align:center;" style="margin-top:30px;">
    
    <h2 style="color:white;">STATISTIKE</h2>
    
	
	
	
	
	
	
	<?php
	
	
	
             $query = "SELECT * FROM police WHERE datumPocetka between '2020-01-01' and '2020-02-01'";
             $result = mysqli_query($connection,$query);
			 $ukupno =0;

             while($row=mysqli_fetch_assoc($result)){

             $kl_id = $row['vrijednost'];  //2
          

				 $ukupno = $ukupno + $kl_id;
				
			 }
			 
			 
			 
			 
			 
			 $query2 = "SELECT * FROM police WHERE datumPocetka between '2020-02-01' and '2020-03-01'";
             $result2 = mysqli_query($connection,$query2);
			 $ukupno2 =0;

             while($row=mysqli_fetch_assoc($result2)){

             $kl_id2 = $row['vrijednost'];  //2
          

				 $ukupno2 = $ukupno2 + $kl_id2;
				
			 }
			 
			 
			 
			 $query3 = "SELECT * FROM police WHERE datumPocetka between '2020-03-01' and '2020-04-01'";
             $result3 = mysqli_query($connection,$query3);
			 $ukupno3 =0;

             while($row=mysqli_fetch_assoc($result3)){

             $kl_id3 = $row['vrijednost'];  //2
          

				 $ukupno3 = $ukupno3 + $kl_id3;
				
			 }
			 
			 
			  $query4 = "SELECT * FROM police WHERE datumPocetka between '2020-04-01' and '2020-05-01'";
             $result4 = mysqli_query($connection,$query4);
			 $ukupno4 =0;

             while($row=mysqli_fetch_assoc($result4)){

             $kl_id4 = $row['vrijednost'];  //2
          

				 $ukupno4 = $ukupno4 + $kl_id4;
				
			 }
			 
			 $query5 = "SELECT * FROM police WHERE datumPocetka between '2020-05-01' and '2020-06-01'";
             $result5 = mysqli_query($connection,$query5);
			 $ukupno5 =0;

             while($row=mysqli_fetch_assoc($result5)){

             $kl_id5 = $row['vrijednost'];  //2
          

				 $ukupno5 = $ukupno5 + $kl_id5;
				
			 }
			 
			 $query6 = "SELECT * FROM police WHERE datumPocetka between '2020-06-01' and '2020-07-01'";
             $result6 = mysqli_query($connection,$query6);
			 $ukupno6 =0;

             while($row=mysqli_fetch_assoc($result6)){

             $kl_id6 = $row['vrijednost'];  //2
          

				 $ukupno6 = $ukupno6 + $kl_id6;
				
			 }
			 
			 $query7 = "SELECT * FROM police WHERE datumPocetka between '2020-07-01' and '2020-08-01'";
             $result7 = mysqli_query($connection,$query7);
			 $ukupno7 =0;

             while($row=mysqli_fetch_assoc($result7)){

             $kl_id7 = $row['vrijednost'];  //2
          

				 $ukupno7 = $ukupno7 + $kl_id7;
				
			 }
			 
			 
			 $query8 = "SELECT * FROM police WHERE datumPocetka between '2020-08-01' and '2020-09-01'";
             $result8 = mysqli_query($connection,$query8);
			 $ukupno8 =0;

             while($row=mysqli_fetch_assoc($result8)){

             $kl_id8 = $row['vrijednost'];  //2
          

				 $ukupno8 = $ukupno8 + $kl_id8;
				
			 }
			 
			 $query9 = "SELECT * FROM police WHERE datumPocetka between '2020-09-01' and '2020-10-01'";
             $result9 = mysqli_query($connection,$query9);
			 $ukupno9 =0;

             while($row=mysqli_fetch_assoc($result9)){

             $kl_id9 = $row['vrijednost'];  //2
          

				 $ukupno9 = $ukupno9 + $kl_id9;
				
			 }
			 
			 $query10 = "SELECT * FROM police WHERE datumPocetka between '2020-10-01' and '2020-11-01'";
             $result10 = mysqli_query($connection,$query10);
			 $ukupno10 =0;

             while($row=mysqli_fetch_assoc($result10)){

             $kl_id10 = $row['vrijednost'];  //2
          

				 $ukupno10 = $ukupno10 + $kl_id10;
				
			 }
			 
			 $query11 = "SELECT * FROM police WHERE datumPocetka between '2020-11-01' and '2020-12-01'";
             $result11 = mysqli_query($connection,$query11);
			 $ukupno11 =0;

             while($row=mysqli_fetch_assoc($result11)){

             $kl_id11 = $row['vrijednost'];  //2
          

				 $ukupno11 = $ukupno11 + $kl_id11;
				
			 }
			 
			 $query12 = "SELECT * FROM police WHERE datumPocetka between '2020-12-01' and '2021-01-01'";
             $result12 = mysqli_query($connection,$query12);
			 $ukupno12 =0;

             while($row=mysqli_fetch_assoc($result12)){

             $kl_id12 = $row['vrijednost'];  //2
          

				 $ukupno12 = $ukupno12 + $kl_id12;
				
			 }
			 
	
	
	
	
	
	
 
$dataPoints = array(
	array("x"=> 1, "y"=> $ukupno),
	array("x"=> 2, "y"=> $ukupno2),
	array("x"=> 3, "y"=> $ukupno3),
	array("x"=> 4, "y"=> $ukupno4),
	array("x"=> 5, "y"=> $ukupno5),
	array("x"=> 6, "y"=> $ukupno6),
	array("x"=> 7, "y"=> $ukupno7),
	array("x"=> 8, "y"=> $ukupno8),
	array("x"=> 9, "y"=> $ukupno9),
	array("x"=> 10, "y"=> $ukupno10),
	array("x"=> 11, "y"=> $ukupno11),
	array("x"=> 12, "y"=> $ukupno12),
	
);
	
?>
<!DOCTYPE HTML>
<html>
<head>  
<script>
window.onload = function () {
 
var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	exportEnabled: true,
	theme: "light1", // "light1", "light2", "dark1", "dark2"
	title:{
		text: "Simple Column Chart with Index Labels"
	},
	data: [{
		type: "column", //change type to bar, line, area, pie, etc
		//indexLabel: "{y}", //Shows y value on all Data Points
		indexLabelFontColor: "#5A5757",
		indexLabelPlacement: "outside",   
		dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
	}]
});
chart.render();
 
}
</script>
</head>
<body>
<div id="chartContainer" style="height: 370px; width: 100%;"></div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</body>
</html>
	
	
	
	
	
	
	
	
	
	
         // <?php

			// $ukupno=0;
            // $query = "SELECT * FROM police";
            // $result = mysqli_query($connection,$query);

            // while($row=mysqli_fetch_assoc($result)){

            // $kl_id = $row['vrijednost'];  //2
            
				
				
				// $ukupno = $ukupno + $kl_id;
				
			
                
			// }
			
			
			// echo "<h6>$ukupno</h6>";
                
           
                                
                    
                                    // ?>
        
    
</div>
                         
                         

               

        
    <br><br>
    
        
    </div>
    <div class="col-md-1" style="background-color:black;">.col</div>
</div>


   

</body>
</html>





