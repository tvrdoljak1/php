<?php  include "db.php";
 
 
 if(isset($_POST["employee_id"]))  
 {  
      $query = "SELECT * FROM police WHERE id = '".$_POST["employee_id"]."'";  
      $result = mysqli_query($connection, $query);  
      $row = mysqli_fetch_array($result);  
      echo json_encode($row);  
 }  
 ?>