<?php include "db.php";

 if(!empty($_POST))  
 {  
      $output = '';  
      $message = '';  
      $brojPolice = mysqli_real_escape_string($connection, $_POST["brojPolice"]);  
      $datumPocetka = mysqli_real_escape_string($connection, $_POST["datumPocetka"]);  
      $datumIsteka = mysqli_real_escape_string($connection, $_POST["datumIsteka"]);  
      $kljent = mysqli_real_escape_string($connection, $_POST["kljent"]);  
      $vrijednost = mysqli_real_escape_string($connection, $_POST["vrijednost"]);  
      $osiguranje = mysqli_real_escape_string($connection, $_POST["osiguranje"]);  
      if($_POST["employee_id"] != '')  
      {  
           $query = "  
           UPDATE police   
           SET brojPolice='$brojPolice',   
           datumPocetka='$datumPocetka',   
           datumIsteka='$datumIsteka',   
           vrijednost = '$vrijednost',   
           klijentId = '$kljent',
           vrsteOsiguranjaId = '$osiguranje'
           WHERE id='".$_POST["employee_id"]."'";  
           //$message = 'Data Updated'; 
          
          
          mysqli_query($connection, $query);
      }  
    

      echo $output;  
 }  
 ?>