<?php include "db.php";


if(isset($_POST['employee_id'])){
    
    
    
    
    $output = '';
          $show_query = "SELECT * FROM police WHERE klijentId = '".$_POST["employee_id"]."'";
          $show_result = mysqli_query($connection,$show_query);
          $output .= '  
          <div class="table-responsive">  
           <table class="table table-bordered">';
            
            

          
          while($show_row = mysqli_fetch_assoc($show_result)){
              
              $kljent_broj_police = $show_row['brojPolice'];
              $kljent_datum_pocetka = $show_row['datumPocetka'];
              $kljent_datum_isteka = $show_row['datumIsteka'];
              $kljent_vrijednost = $show_row['vrijednost'];
              $kljent_osiguranje = $show_row['vrsteOsiguranjaId'];
              
              
              $query_osig = "SELECT * FROM vrsteosiguranja WHERE id = $kljent_osiguranje";
              $osig_result = mysqli_query($connection,$query_osig);
              
              
                while($osig_row = mysqli_fetch_assoc($osig_result)){
                  
                    $osig_naziv = $osig_row['naziv'];
                  

                    
                  $output .= '  
                        <tr>  
                             <td width="30%"><label>Broj Police:</label></td>  
                             <td width="70%">'.$show_row["brojPolice"].'</td>  
                        </tr>  
                        <tr>  
                             <td width="30%"><label>Datum pocetka:</label></td>  
                             <td width="70%">'.$show_row["datumPocetka"].'</td>  
                        </tr>  
                        <tr>  
                             <td width="30%"><label>Datum isteka:</label></td>  
                             <td width="70%">'.$show_row["datumIsteka"].'</td>  
                        </tr>  
                        <tr>  
                             <td width="30%"><label>Vrijednost:</label></td>  
                             <td width="70%">'.$show_row["vrijednost"].'</td>  
                        </tr>  
                         <tr>  
                             <td width="30%"><label>Osiguranje:</label></td>  
                             <td width="70%">'.$osig_row["naziv"].'</td>  
                        </tr> 
                        ';  
                    
                  
                  
              }
              $output .= "</table></div>";  
              echo $output;
              
              
              
          }
    
    
    
    
    
    
    
}



?>