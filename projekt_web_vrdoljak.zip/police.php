



<!--    PITANJE  1. delete refresh stranica  2. date se ne zeli upisati u bazu  3. jel triba login posto ne pise u zadatku  4. jel triba brisat kljente jer isto ne pise u zadataku   -->













<?php // INCLUDE BAZA

include "db.php";

?>

<!-- HTML BEGINS -->

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="style.css">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
 
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="row">
    <div class="col-md-1" style="background-color:black;">.col</div>
    <div class="col-md-10" style="background-color:dimGray;">
    
    
    <ul>
      <li><a class="active" href="#home">Home</a></li>
      <li><a href="#news">News</a></li>
      <li><a href="police.php">Police</a></li>
      <li><a href="klijenti.php">Klijenti</a></li>
	  <li><a href="statistika.php">Statistika</a></li>
    </ul>
    
    
    
    <?php
    
                if(isset($_GET['delete'])){
                    
                    $del_broj = $_GET['delete'];
                    
                    $del_query = "DELETE FROM police WHERE id = $del_broj";
                    $del_result = mysqli_query($connection,$del_query);
                   // header("Location: police.php");
                    
                    
                }
                    
    
                ?>
    
    

<!-- Modal -->
<div class="modal fade" id="dodajpolicu" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Dodaj Policu</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         
         
         
         
         
         
         
         
         <?php
    
    

        
        
     if(isset($_POST['submit'])){
               
           $klijent = $_POST['name'];
           $osiguranje = $_POST['osiguranje'];
           $broj_police = $_POST['br_police'];
           $vrijednost = $_POST['vrijednost'];
           $date_start = $_POST['date_start'];
           $date_end = $_POST['date_end'];
           $date_for_database_start = date ("Y-m-d H:i:s", strtotime($date_start));
           $date_for_database_end = date ("Y-m-d H:i:s", strtotime($date_end));
    
     
$query = "INSERT INTO police (brojPolice, datumPocetka, datumIsteka, vrijednost, klijentId, vrsteOsiguranjaId)
        VALUES ('".$broj_police."',  '".$date_for_database_start."', '".$date_for_database_end."', '".$vrijednost."', '".$klijent."', '".$osiguranje."')";
        
        $res = mysqli_query($connection,$query);
 
        
           
       
        
     }
    ?>


<br>

                    <form action="police.php" method="post">
                        
                    
                        <div class="form-group">
                           
                            <label for="kljent">Kljent:</label>
                            <select name = "name" id="kljent" class="form-control">
                            
                                    <?php

                                    $query_select_names = "SELECT * FROM klijent";
                                    $result_select_names = mysqli_query($connection,$query_select_names);

                                    while($row_select_names = mysqli_fetch_assoc($result_select_names)){

                                    $kljent_id = $row_select_names['id'];
                                    $name = $row_select_names['ime'];
                                    $prezime = $row_select_names['prezime'];
                                    $full_name = $name . " " . $prezime;

                                    echo "<option value='$kljent_id'>$full_name</option>"; 

                                    }

                                    ?>
 
                            </select>
                            </div>
                    
                            <div class="form-group">
                                <label for="osig">Osiguranje:</label>
                                <select name = "osiguranje" id="osig" class="form-control">
                            
                                <?php

                                $query_select_osiguranje = "SELECT * FROM vrsteosiguranja";
                                $result_select_osiguranje = mysqli_query($connection,$query_select_osiguranje);

                                while($row_select_osiguranje = mysqli_fetch_assoc($result_select_osiguranje)){

                                $name_osig = $row_select_osiguranje['naziv'];
                                $id_osig = $row_select_osiguranje['id'];


                                echo "<option value='$id_osig'>$name_osig</option>";



                                }

                                ?>
                            
                            
                        </select>
                            </div>
                        
                        <div class="form-group">
                            <label for="br_police">Broj police:</label>
                            <input type="text" name="br_police" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="vrijednost">Vrijednost:</label>
                            <input type="text" name="vrijednost" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="date_start">Datum pocetka:</label>
                            <input type="date" name="date_start" min="1950-12-31" class="form-control" >
                        </div>
                        <div class="form-group">
                            <label for="date_end">Datum zavrsetka:</label>
                            <input type="date" name="date_end" min="1950-12-31" class="form-control">
                            </div>
                        <input type="submit" name = "submit" value="Dodaj novu policu" class="btn btn-primary">

                </form> 
                            
                            
                            
                            <br><br>
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
      </div>
      
    </div>
  </div>
</div>
    
    
<!--#####################################################################################################################-->
    
    

    
    
    
 <!--#####################################################################################################################-->
    
    
    
    
    <br><br><br>
<div class="container" style="text-align:center;" style="margin-top:30px;">
    
    <h2 style="color:white;">PRIKAZ SVIH POLICA OSIGURANJA</h2>
    
        
        
    
</div>
                         
                         
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#dodajpolicu">
                  Add Data
                </button>
                <br><br>
<div class="employee_table">
<table class="table table-dark table-striped">
    
    <tr>    
           
            <th>Ime i prezime</th>
            <th>Grad</th>
            <th>OIB</th>
            <th>Broj police</th>
            <th>Datum pocetka</th>
            <th>Datum isteka</th>
            <th>Vrijednost</th>
            <th>Tip osiguranje</th>
            <th>Brisati</th>
            <th>Azurirati</th>
            
          
            </tr>
            
            
            
            <?php

            $query = "SELECT * FROM klijent";
            $result = mysqli_query($connection,$query);

            while($row=mysqli_fetch_assoc($result)){

            $kl_id = $row['id'];  //2
            $kl_ime = $row['ime'];
            $kl_prezime = $row['prezime'];
            $kl_grad = $row['grad'];
            $kl_oib = $row['oib'];
                
                
                $query_police = "SELECT * FROM police WHERE klijentId = $kl_id";
                $result_police = mysqli_query($connection,$query_police);
                
                while($row_police = mysqli_fetch_assoc($result_police)){
                    
                    $police_id = $row_police['id'];
                    $vrs_police = $row_police['vrsteOsiguranjaId'];
                    $police_broj = $row_police['brojPolice'];
                    $police_datumP = $row_police['datumPocetka'];
                    $police_datumZ = $row_police['datumIsteka'];
                    $police_vrijednost = $row_police['vrijednost'];
                    
                            
                        $query_osig = "SELECT * FROM vrsteosiguranja WHERE id = $vrs_police";
                        $result_osig = mysqli_query($connection,$query_osig);
                    
                             while($row_osig = mysqli_fetch_assoc($result_osig)){
                    
                                $osig_naziv = $row_osig['naziv'];
                                
                    
                                    ?>

            <tr>

            <td><?php echo $kl_ime . " " . $kl_prezime; ?></td>
            <td><?php echo $kl_grad ?></td>
            <td><?php echo $kl_oib ?></td>
            <td><?php echo $police_broj ?></td>
            <td><?php echo $police_datumP ?></td>
            <td><?php echo $police_datumZ ?></td>
            <td><?php echo $police_vrijednost ?></td>
            <td><?php echo $osig_naziv ?></td>

           
          <td><?php echo "<a href='police.php?delete={$police_id}' class='btn btn-primary'>Delete</a>" ?></td>
                
                
                
            <td><input type="button" name="edit" value="Edit" id="<?php echo $row_police["id"]; ?>" class="btn btn-primary btn-xs edit_data" /></td>
            
            </tr>

             <?php
                                }


                            }
            }
                        
                ?>
                
                
                <?php
    
                    
                    if(isset($_GET['update'])){
                        $upd_id = $_GET['update'];
                        
                        include "update_police.php";
                        
                        ?>
    
                        
                    
                      <?php
    
                       
                       
                        
                  
                       
                    }
    
   
                ?>
                
                
    
 
 

</table>
        </div>
        
    <br><br>
    
        
    </div>
    <div class="col-md-1" style="background-color:black;">.col</div>
</div>


   

</body>
</html>



<div id="add_data_Modal" class="modal fade">  
      <div class="modal-dialog">  
           <div class="modal-content">  
                <div class="modal-header">  
                     <button type="button" class="close" data-dismiss="modal">&times;</button>  
                     <h4 class="modal-title">Uredi policu</h4>  
                </div>  
                <div class="modal-body">  
                     <form method="post" id="insert_form">   
                          <input type="text" name="brojPolice" id="brojPolice" class="form-control" />  
                          <br />  
                          <input type="text" name="datumPocetka" id="datumPocetka" class="form-control">
                          <br />  
                          <input type="text" name="datumIsteka" id="datumIsteka" class="form-control">
                          <br />  
                          <select name = "kljent" id="kljent" class="form-control">
                            
                                    <?php

                                    $query_select_names = "SELECT * FROM klijent";
                                    $result_select_names = mysqli_query($connection,$query_select_names);

                                    while($row_select_names = mysqli_fetch_assoc($result_select_names)){

                                    $kljent_id = $row_select_names['id'];
                                    $name = $row_select_names['ime'];
                                    $prezime = $row_select_names['prezime'];
                                    $full_name = $name . " " . $prezime;

                                    echo "<option value='$kljent_id'>$full_name</option>"; 

                                    }

                                    ?>
 
                          </select>
                          <br />   
                          <input type="text" name="vrijednost" id="vrijednost" class="form-control" />  
                          <br />  
                           <select name = "osiguranje" id="osiguranje" class="form-control">
                            
                                <?php

                                $query_select_osiguranje = "SELECT * FROM vrsteosiguranja";
                                $result_select_osiguranje = mysqli_query($connection,$query_select_osiguranje);

                                while($row_select_osiguranje = mysqli_fetch_assoc($result_select_osiguranje)){

                                $name_osig = $row_select_osiguranje['naziv'];
                                $id_osig = $row_select_osiguranje['id'];


                                echo "<option value='$id_osig'>$name_osig</option>";



                                }

                                ?>
                            
                            
                        </select>
                          
                          <br />  
                          <input type="text" name="employee_id" id="employee_id" />  
                          <input type="submit" name="insert" id="insert" value="Insert" class="btn btn-success" />  
                     </form>  
                </div>  
                <div class="modal-footer">  
                     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
                </div>  
           </div>  
      </div>  
 </div>  





<script>
    
    
    
   $(document).ready(function(){  
      
      $(document).on('click', '.edit_data', function(){  
           var employee_id = $(this).attr("id");  
           $.ajax({  
                url:"fetch.php",  
                method:"POST",  
                data:{employee_id:employee_id},  
                dataType:"json",  
                success:function(data){  
                     $('#brojPolice').val(data.brojPolice);  
                     $('#datumPocetka').val(data.datumPocetka);  
                     $('#datumIsteka').val(data.datumIsteka);  
                     $('#kljent').val(data.kljent);  
                     $('#vrijednost').val(data.vrijednost);  
                     $('#osiguranje').val(data.vrsteOsiguranjaId); 
                     $('#employee_id').val(data.id);  
                     $('#insert').val("Update");  
                     $('#add_data_Modal').modal('show');  
               
                } //end succes function  
               
           });  // end ajax 
          
      }); //end document on click function  
     
        $('#insert_form').on("submit", function(event){  
           event.preventDefault();  
           if($('#brojPolice').val() == "")  
           {  
                alert("Broj ppolice is required");  
           }  
           else if($('#datumPocetka').val() == '')  
           {  
                alert("Datum pocetka is required");  
           }  
           else if($('#datumIsteka').val() == '')  
           {  
                alert("Datum isteka is required");  
           }  
           else if($('#kljent').val() == '')  
           {  
                alert("Kljent is required");  
           }  
            else if($('#vrijednost').val() == '')  
           {  
                alert("Vrijednost is required");  
           }  
             else if($('#osiguranje').val() == '')  
           {  
                alert("Osiguranje is required");  
           } 
           else  //ODE SAN STA
           {  
                $.ajax({  
                     url:"insert.php",  
                     method:"POST",  
                     data:$('#insert_form').serialize(),  
                     beforeSend:function(){  
                          $('#insert').val("Inserting");  
                     },  
                     success:function(data){  
                          $('#insert_form')[0].reset();  
                          $('#add_data_Modal').modal('hide');  
                          $('#employee_table').html(data);  
                     }  
                });
           }
       
 }); 
       
    
       }); //end main function
    
</script>













